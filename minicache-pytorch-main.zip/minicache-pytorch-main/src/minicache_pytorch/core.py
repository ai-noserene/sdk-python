from __future__ import annotations

import torch


def l2_normalize(tensor: torch.Tensor, dim: int = -1, eps: float = 1e-8) -> torch.Tensor:
    norm = tensor.norm(dim=dim, keepdim=True).clamp_min(eps)
    return tensor / norm


def decompose_magnitude_direction(
    tensor: torch.Tensor,
    dim: int = -1,
    eps: float = 1e-8,
) -> tuple[torch.Tensor, torch.Tensor]:
    magnitude = tensor.norm(dim=dim, keepdim=True).clamp_min(eps)
    direction = tensor / magnitude
    return magnitude, direction


def direction_interpolate(
    lower_direction: torch.Tensor,
    upper_direction: torch.Tensor,
    alpha: float = 0.5,
) -> torch.Tensor:
    if not 0.0 <= alpha <= 1.0:
        raise ValueError("alpha must be in [0, 1]")

    mixed = (1.0 - alpha) * lower_direction + alpha * upper_direction
    return l2_normalize(mixed)


def cosine_similarity_per_token(
    lower: torch.Tensor,
    upper: torch.Tensor,
    dim: int = -1,
    eps: float = 1e-8,
) -> torch.Tensor:
    lower_dir = l2_normalize(lower, dim=dim, eps=eps)
    upper_dir = l2_normalize(upper, dim=dim, eps=eps)
    return (lower_dir * upper_dir).sum(dim=dim)


def retention_mask_from_similarity(
    lower: torch.Tensor,
    upper: torch.Tensor,
    threshold: float = 0.9,
    dim: int = -1,
    eps: float = 1e-8,
) -> torch.Tensor:
    if not -1.0 <= threshold <= 1.0:
        raise ValueError("threshold must be in [-1, 1]")

    similarity = cosine_similarity_per_token(lower, upper, dim=dim, eps=eps)
    return similarity < threshold


def compress_adjacent_pair(
    lower: torch.Tensor,
    upper: torch.Tensor,
    alpha: float = 0.5,
) -> torch.Tensor:
    if lower.shape != upper.shape:
        raise ValueError("lower and upper tensors must share the same shape")

    lower_mag, lower_dir = decompose_magnitude_direction(lower)
    upper_mag, upper_dir = decompose_magnitude_direction(upper)

    mixed_dir = direction_interpolate(lower_dir, upper_dir, alpha=alpha)

    # Experimental default: keep the upper-layer magnitude while interpolating direction.
    return upper_mag * mixed_dir


def compress_adjacent_pair_with_retention(
    lower: torch.Tensor,
    upper: torch.Tensor,
    alpha: float = 0.5,
    threshold: float = 0.9,
) -> tuple[torch.Tensor, torch.Tensor]:
    compressed = compress_adjacent_pair(lower, upper, alpha=alpha)
    keep_mask = retention_mask_from_similarity(lower, upper, threshold=threshold)

    # Tokens marked for retention stay on the original upper-layer path.
    output = torch.where(keep_mask.unsqueeze(-1), upper, compressed)
    return output, keep_mask
