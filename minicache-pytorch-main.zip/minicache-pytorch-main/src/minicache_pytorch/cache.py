from __future__ import annotations

from dataclasses import dataclass

import torch

from .core import compress_adjacent_pair_with_retention


@dataclass(frozen=True)
class CompressionResult:
    cache: "LayerKVCache"
    key_keep_mask: torch.Tensor
    value_keep_mask: torch.Tensor

    @property
    def retained_token_fraction(self) -> float:
        key_fraction = self.key_keep_mask.float().mean()
        value_fraction = self.value_keep_mask.float().mean()
        return ((key_fraction + value_fraction) / 2).item()


@dataclass(frozen=True)
class LayerKVCache:
    keys: torch.Tensor
    values: torch.Tensor

    def __post_init__(self) -> None:
        if self.keys.shape != self.values.shape:
            raise ValueError("keys and values must share the same shape")
        if self.keys.ndim < 4:
            raise ValueError("cache tensors must have shape (layers, batch, seq, dim)")

    @property
    def num_layers(self) -> int:
        return self.keys.shape[0]

    @property
    def num_tokens(self) -> int:
        return self.keys.shape[-2]

    @property
    def hidden_dim(self) -> int:
        return self.keys.shape[-1]

    @property
    def shape(self) -> torch.Size:
        return self.keys.shape

    @property
    def nbytes(self) -> int:
        return self.keys.element_size() * self.keys.numel() + self.values.element_size() * self.values.numel()

    def clone(self) -> "LayerKVCache":
        return LayerKVCache(keys=self.keys.clone(), values=self.values.clone())

    def compress_layer_pair(
        self,
        lower_layer: int,
        upper_layer: int,
        alpha: float = 0.5,
        threshold: float = 0.9,
    ) -> CompressionResult:
        self._validate_adjacent_layers(lower_layer, upper_layer)

        keys = self.keys.clone()
        values = self.values.clone()

        compressed_keys, key_keep_mask = compress_adjacent_pair_with_retention(
            keys[lower_layer],
            keys[upper_layer],
            alpha=alpha,
            threshold=threshold,
        )
        compressed_values, value_keep_mask = compress_adjacent_pair_with_retention(
            values[lower_layer],
            values[upper_layer],
            alpha=alpha,
            threshold=threshold,
        )

        keys[upper_layer] = compressed_keys
        values[upper_layer] = compressed_values

        return CompressionResult(
            cache=LayerKVCache(keys=keys, values=values),
            key_keep_mask=key_keep_mask,
            value_keep_mask=value_keep_mask,
        )

    def _validate_adjacent_layers(self, lower_layer: int, upper_layer: int) -> None:
        if lower_layer < 0 or upper_layer < 0:
            raise ValueError("layer indices must be non-negative")
        if lower_layer >= self.num_layers or upper_layer >= self.num_layers:
            raise ValueError("layer indices are outside the cache")
        if upper_layer != lower_layer + 1:
            raise ValueError("MiniCache pair compression expects adjacent layers")
