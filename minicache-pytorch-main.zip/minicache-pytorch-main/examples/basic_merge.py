from __future__ import annotations

import torch

from minicache_pytorch import compress_adjacent_pair_with_retention


def main() -> None:
    torch.manual_seed(0)

    lower = torch.randn(2, 16, 64)
    upper = torch.randn(2, 16, 64)

    compressed, keep_mask = compress_adjacent_pair_with_retention(
        lower,
        upper,
        alpha=0.5,
        threshold=0.92,
    )

    print("compressed shape:", tuple(compressed.shape))
    print("retained tokens:", int(keep_mask.sum().item()))


if __name__ == "__main__":
    main()
