from __future__ import annotations

import torch

from minicache_pytorch import LayerKVCache


def main() -> None:
    torch.manual_seed(0)

    keys = torch.randn(8, 2, 128, 64)
    values = torch.randn(8, 2, 128, 64)
    keys[5] = keys[4] + 0.2 * torch.randn_like(keys[4])
    values[5] = values[4] + 0.2 * torch.randn_like(values[4])
    cache = LayerKVCache(keys=keys, values=values)

    result = cache.compress_layer_pair(4, 5, alpha=0.5, threshold=0.98)

    print(f"cache shape: {tuple(cache.shape)}")
    print(f"cache bytes: {cache.nbytes:,}")
    print(f"compressed pair: layers 4 -> 5")
    print(f"retained token fraction: {result.retained_token_fraction:.3f}")


if __name__ == "__main__":
    main()
