# minicache-pytorch

Clean-room PyTorch primitives for studying MiniCache-style KV-cache compression.

Paper:

- <https://arxiv.org/abs/2405.14366>

Official references:

- project page: <https://minicache.vmv.re/>
- official repo: <https://github.com/AkideLiu/MiniCache>

## What this implements

There is already an official MiniCache repository.

This package focuses on the smallest pieces needed to inspect and reproduce the core idea:

- a smaller package surface
- explicit install and test steps
- inspectable tensor primitives
- runnable examples
- benchmark scripts
- a README that explains what is implemented and what is not

This is not the official implementation and does not claim paper parity. It is an educational reproduction of the
core tensor behavior, with tests and examples that make the method easier to read.

## Scope

Current scope:

- magnitude / direction decomposition
- adjacent-layer direction interpolation
- per-token cosine similarity
- a simple retention-mask primitive
- retention-aware adjacent-layer compression
- a small `LayerKVCache` object for applying the pairwise path to stored keys and values
- tests for the low-level pieces

The broader writeup, animations, and interactive notes live in:

- `cache-atlas`

## Quick start

```bash
uv sync --extra dev
uv run --extra dev pytest
```

## Install

```bash
uv pip install -e .[dev]
```

## Usage

```python
import torch

from minicache_pytorch import compress_adjacent_pair_with_retention

lower = torch.randn(2, 16, 64)
upper = torch.randn(2, 16, 64)

compressed, keep_mask = compress_adjacent_pair_with_retention(
    lower,
    upper,
    alpha=0.5,
    threshold=0.92,
)

print(compressed.shape)
print(keep_mask.shape)
```

## Example

```bash
uv run python examples/basic_merge.py
uv run python examples/cache_object.py
```

## Benchmark

```bash
uv run python scripts/bench_pair.py
```

## Roadmap

1. keep the tensor primitives readable
2. benchmark simple adjacent-layer compression behavior
3. add clearer retention-policy utilities
4. move upward toward a fuller cache-compression path

## Development

```bash
uv run --extra dev pytest
```
