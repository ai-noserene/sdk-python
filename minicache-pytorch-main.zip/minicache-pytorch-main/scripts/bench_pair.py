from __future__ import annotations

import time

import torch

from minicache_pytorch import compress_adjacent_pair, compress_adjacent_pair_with_retention


def benchmark(fn, lower: torch.Tensor, upper: torch.Tensor, steps: int = 200) -> float:
    start = time.perf_counter()
    for _ in range(steps):
        fn(lower, upper)
    end = time.perf_counter()
    return (end - start) / steps


def main() -> None:
    torch.manual_seed(0)

    lower = torch.randn(4, 512, 128)
    upper = torch.randn(4, 512, 128)

    plain = benchmark(compress_adjacent_pair, lower, upper)
    retained = benchmark(
        lambda a, b: compress_adjacent_pair_with_retention(a, b, threshold=0.92),
        lower,
        upper,
    )

    print(f"plain compress_adjacent_pair: {plain * 1e3:.3f} ms")
    print(f"retention-aware pair path:   {retained * 1e3:.3f} ms")


if __name__ == "__main__":
    main()
