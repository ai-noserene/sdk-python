import torch

from minicache_pytorch import (
    compress_adjacent_pair_with_retention,
    compress_adjacent_pair,
    cosine_similarity_per_token,
    decompose_magnitude_direction,
    direction_interpolate,
    l2_normalize,
    retention_mask_from_similarity,
)


def test_l2_normalize_outputs_unit_vectors():
    tensor = torch.randn(4, 8)
    normalized = l2_normalize(tensor)
    norms = normalized.norm(dim=-1)
    assert torch.allclose(norms, torch.ones_like(norms), atol=1e-5)


def test_decompose_magnitude_direction_reconstructs_tensor():
    tensor = torch.randn(2, 3, 5)
    magnitude, direction = decompose_magnitude_direction(tensor)
    reconstructed = magnitude * direction
    assert torch.allclose(reconstructed, tensor, atol=1e-5)


def test_direction_interpolate_preserves_unit_norm():
    a = l2_normalize(torch.randn(2, 6))
    b = l2_normalize(torch.randn(2, 6))
    mixed = direction_interpolate(a, b, alpha=0.3)
    norms = mixed.norm(dim=-1)
    assert torch.allclose(norms, torch.ones_like(norms), atol=1e-5)


def test_compress_adjacent_pair_keeps_shape():
    lower = torch.randn(2, 16, 32)
    upper = torch.randn(2, 16, 32)
    compressed = compress_adjacent_pair(lower, upper)
    assert compressed.shape == upper.shape


def test_compress_adjacent_pair_keeps_upper_magnitude():
    lower = torch.randn(2, 4, 8)
    upper = torch.randn(2, 4, 8)
    compressed = compress_adjacent_pair(lower, upper)
    upper_mag = upper.norm(dim=-1)
    compressed_mag = compressed.norm(dim=-1)
    assert torch.allclose(upper_mag, compressed_mag, atol=1e-5)


def test_cosine_similarity_per_token_matches_expected_extremes():
    a = torch.tensor([[[1.0, 0.0], [0.0, 1.0]]])
    b = torch.tensor([[[1.0, 0.0], [0.0, -1.0]]])
    similarity = cosine_similarity_per_token(a, b)
    assert torch.allclose(similarity, torch.tensor([[1.0, -1.0]]), atol=1e-5)


def test_retention_mask_flags_low_similarity_tokens():
    lower = torch.tensor([[[1.0, 0.0], [0.0, 1.0]]])
    upper = torch.tensor([[[1.0, 0.0], [0.0, -1.0]]])
    keep_mask = retention_mask_from_similarity(lower, upper, threshold=0.5)
    assert torch.equal(keep_mask, torch.tensor([[False, True]]))


def test_compress_with_retention_keeps_marked_tokens_on_upper_path():
    lower = torch.tensor([[[1.0, 0.0], [0.0, 1.0]]])
    upper = torch.tensor([[[1.0, 0.0], [0.0, -2.0]]])
    output, keep_mask = compress_adjacent_pair_with_retention(lower, upper, alpha=0.5, threshold=0.5)
    assert torch.equal(keep_mask, torch.tensor([[False, True]]))
    assert torch.allclose(output[:, 1], upper[:, 1], atol=1e-5)
