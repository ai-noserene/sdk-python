import pytest
import torch

from minicache_pytorch import LayerKVCache


def make_cache(layers: int = 4) -> LayerKVCache:
    torch.manual_seed(0)
    keys = torch.randn(layers, 2, 8, 16)
    values = torch.randn(layers, 2, 8, 16)
    return LayerKVCache(keys=keys, values=values)


def test_layer_kv_cache_requires_matching_key_value_shapes():
    keys = torch.randn(2, 1, 4, 8)
    values = torch.randn(3, 1, 4, 8)
    with pytest.raises(ValueError, match="same shape"):
        LayerKVCache(keys=keys, values=values)


def test_layer_kv_cache_requires_layer_batch_seq_dim_shape():
    keys = torch.randn(2, 4, 8)
    values = torch.randn(2, 4, 8)
    with pytest.raises(ValueError, match="layers, batch, seq, dim"):
        LayerKVCache(keys=keys, values=values)


def test_compress_layer_pair_preserves_cache_shape():
    cache = make_cache()
    result = cache.compress_layer_pair(1, 2, threshold=0.5)
    assert result.cache.shape == cache.shape
    assert result.key_keep_mask.shape == cache.keys[1].shape[:-1]
    assert result.value_keep_mask.shape == cache.values[1].shape[:-1]


def test_compress_layer_pair_only_updates_upper_layer():
    cache = make_cache()
    result = cache.compress_layer_pair(1, 2, threshold=-1.0)
    assert torch.allclose(result.cache.keys[0], cache.keys[0])
    assert torch.allclose(result.cache.keys[1], cache.keys[1])
    assert not torch.allclose(result.cache.keys[2], cache.keys[2])
    assert torch.allclose(result.cache.keys[3], cache.keys[3])


def test_compress_layer_pair_keeps_retained_tokens_on_upper_path():
    keys = torch.zeros(2, 1, 2, 2)
    values = torch.zeros(2, 1, 2, 2)
    keys[0] = torch.tensor([[[1.0, 0.0], [0.0, 1.0]]])
    keys[1] = torch.tensor([[[1.0, 0.0], [0.0, -2.0]]])
    values[0] = keys[0]
    values[1] = keys[1]

    cache = LayerKVCache(keys=keys, values=values)
    result = cache.compress_layer_pair(0, 1, threshold=0.5)

    assert torch.equal(result.key_keep_mask, torch.tensor([[False, True]]))
    assert torch.allclose(result.cache.keys[1, :, 1], keys[1, :, 1])
    assert torch.allclose(result.cache.values[1, :, 1], values[1, :, 1])


def test_compress_layer_pair_rejects_non_adjacent_layers():
    cache = make_cache()
    with pytest.raises(ValueError, match="adjacent"):
        cache.compress_layer_pair(0, 2)


def test_cache_nbytes_counts_keys_and_values():
    cache = make_cache(layers=2)
    expected = cache.keys.element_size() * cache.keys.numel() + cache.values.element_size() * cache.values.numel()
    assert cache.nbytes == expected
